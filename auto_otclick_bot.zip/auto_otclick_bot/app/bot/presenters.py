from __future__ import annotations

import html
import json

from app.models import LeadRecord, TaskRecord


def money(value: int | None) -> str:
    return f"{value:,} ₽".replace(",", " ") if value else "не указан"


def task_card(record: TaskRecord) -> str:
    risk_flags = []
    try:
        risk_flags = json.loads(record.risk_flags or "[]")
    except json.JSONDecodeError:
        pass
    risks = "\n".join(f"• {html.escape(str(risk))}" for risk in risk_flags) or "не выявлены"
    return (
        f"<b>{html.escape(record.source.upper())}: {html.escape(record.title)}</b>\n\n"
        f"<b>Соответствие:</b> {record.relevance_score}/100\n"
        f"<b>Тип:</b> {html.escape(record.project_type)}\n"
        f"<b>Сложность:</b> {html.escape(record.complexity)}\n"
        f"<b>Бюджет:</b> {money(record.budget)}\n"
        f"<b>Рекомендуемая цена:</b> {money(record.recommended_price)}\n"
        f"<b>Срок:</b> {record.deadline_days} дн.\n\n"
        f"<b>Риски:</b>\n{risks}\n\n"
        f"<b>Почему подходит:</b> {html.escape(record.reasoning_summary or '—')}"
    )


def lead_card(record: LeadRecord) -> str:
    try:
        phones = json.loads(record.phones or "[]")
    except json.JSONDecodeError:
        phones = []
    phone_text = ", ".join(html.escape(str(phone)) for phone in phones) or "не найден"
    rating = f"{record.rating:g}" if record.rating is not None else "—"
    reviews = str(record.review_count) if record.review_count is not None else "—"
    website = html.escape(record.website) if record.website else "нет"
    return (
        f"<b>{html.escape(record.company)}</b>\n"
        f"{html.escape(record.city)} · {html.escape(record.category)}\n\n"
        f"<b>Телефон:</b> <code>{phone_text}</code>\n"
        f"<b>Сайт:</b> {website}\n"
        f"<b>Проблема:</b> {html.escape(record.issue)}\n"
        f"<b>Рейтинг:</b> {rating} · отзывов: {reviews}\n"
        f"<b>Цена предложения:</b> {money(record.recommended_price)}"
    )
