from aiogram.fsm.state import State, StatesGroup


class ManualTaskState(StatesGroup):
    waiting_for_task = State()


class TwoGisSearchState(StatesGroup):
    waiting_for_query = State()
