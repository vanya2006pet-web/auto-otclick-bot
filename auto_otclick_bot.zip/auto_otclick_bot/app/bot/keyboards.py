from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, KeyboardButton, ReplyKeyboardMarkup


MAIN_MENU = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="📝 Разобрать задание"), KeyboardButton(text="🏢 Найти компании")],
        [KeyboardButton(text="📊 Статистика"), KeyboardButton(text="⚙️ Проверка настройки")],
    ],
    resize_keyboard=True,
    input_field_placeholder="Выберите действие",
)


def task_keyboard(task_id: int, url: str | None) -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(text="📋 Получить отклик", callback_data=f"task_reply:{task_id}"),
            InlineKeyboardButton(text="💰 Цена", callback_data=f"task_price:{task_id}"),
        ],
        [
            InlineKeyboardButton(text="✅ Откликнулся", callback_data=f"task_done:{task_id}"),
            InlineKeyboardButton(text="⏭ Пропустить", callback_data=f"task_skip:{task_id}"),
        ],
    ]
    if url and url.startswith(("http://", "https://")):
        rows.insert(0, [InlineKeyboardButton(text="🔗 Открыть задание", url=url)])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def lead_keyboard(lead_id: int, source_url: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="📋 Получить сообщение", callback_data=f"lead_message:{lead_id}")],
            [InlineKeyboardButton(text="🗺 Открыть 2ГИС", url=source_url)],
            [
                InlineKeyboardButton(text="📞 Связался", callback_data=f"lead_contacted:{lead_id}"),
                InlineKeyboardButton(text="⏭ Пропустить", callback_data=f"lead_skip:{lead_id}"),
            ],
        ]
    )
