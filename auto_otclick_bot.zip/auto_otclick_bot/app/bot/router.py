from __future__ import annotations

import html
import json
import logging

from aiogram import F, Router
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.bot.keyboards import MAIN_MENU, lead_keyboard, task_keyboard
from app.bot.presenters import lead_card, money, task_card
from app.bot.states import ManualTaskState, TwoGisSearchState
from app.services.container import AppServices

logger = logging.getLogger(__name__)
router = Router()


def authorized(user_id: int, services: AppServices) -> bool:
    admins = services.settings.telegram_admin_ids
    return not admins or user_id in admins


async def deny(message: Message) -> None:
    await message.answer("Доступ к этому боту ограничен владельцем.")


@router.message(Command("whoami"))
async def whoami(message: Message) -> None:
    await message.answer(f"Ваш Telegram ID: <code>{message.from_user.id}</code>")


@router.message(CommandStart())
async def start(message: Message, services: AppServices) -> None:
    if not authorized(message.from_user.id, services):
        await deny(message)
        return
    warning = ""
    if not services.settings.telegram_admin_ids:
        warning = "\n\n⚠️ TELEGRAM_ADMIN_IDS не задан: бот временно доступен любому пользователю."
    await message.answer(
        "<b>Auto Otclick</b>\n\n"
        "Я анализирую задания Kwork и YouDo, рассчитываю конкурентную цену, готовлю отклик "
        "и ищу компании без сайта через 2ГИС. Отправка на площадки и компаниям остаётся под вашим контролем."
        + warning,
        reply_markup=MAIN_MENU,
    )


@router.message(Command("new"))
@router.message(F.text == "📝 Разобрать задание")
async def new_task(message: Message, state: FSMContext, services: AppServices) -> None:
    if not authorized(message.from_user.id, services):
        await deny(message)
        return
    await state.set_state(ManualTaskState.waiting_for_task)
    await message.answer(
        "Пришлите одним сообщением название, описание задания, бюджет и ссылку. "
        "Можно просто переслать или вставить весь текст с Kwork/YouDo."
    )


@router.message(ManualTaskState.waiting_for_task)
async def process_manual_task(message: Message, state: FSMContext, services: AppServices) -> None:
    if not authorized(message.from_user.id, services):
        await deny(message)
        return
    if not message.text or len(message.text.strip()) < 20:
        await message.answer("Описание слишком короткое. Пришлите текст задания целиком.")
        return
    await state.clear()
    status = await message.answer("Анализирую задание…")
    task = services.parser.parse_manual(message.text)
    proposal = await services.ai.analyze_task(task)
    record = await services.repository.add_task(task, proposal)
    if record is None:
        await status.edit_text("Это задание уже было обработано.")
        return
    await status.edit_text(task_card(record), reply_markup=task_keyboard(record.id, record.url))


@router.message(Command("search"))
@router.message(F.text == "🏢 Найти компании")
async def search_companies(message: Message, state: FSMContext, services: AppServices) -> None:
    if not authorized(message.from_user.id, services):
        await deny(message)
        return
    if not services.settings.two_gis_api_key:
        await message.answer(
            "Поиск 2ГИС пока не подключён. Добавьте <code>TWO_GIS_API_KEY</code> в переменные Render. "
            "После этого команда заработает без изменения кода."
        )
        return
    await state.set_state(TwoGisSearchState.waiting_for_query)
    await message.answer(
        "Введите запрос в формате:\n<code>город | категория | количество</code>\n\n"
        "Например: <code>Казань | стоматологии | 10</code>"
    )


@router.message(TwoGisSearchState.waiting_for_query)
async def process_search(message: Message, state: FSMContext, services: AppServices) -> None:
    if not authorized(message.from_user.id, services):
        await deny(message)
        return
    parts = [part.strip() for part in (message.text or "").split("|")]
    if len(parts) < 2:
        await message.answer("Нужен формат: <code>город | категория | количество</code>")
        return
    city, category = parts[0], parts[1]
    try:
        requested = int(parts[2]) if len(parts) > 2 else 10
    except ValueError:
        requested = 10
    limit = min(max(requested, 1), services.settings.max_leads_per_search)
    await state.clear()
    status = await message.answer(f"Ищу компании: {html.escape(city)}, {html.escape(category)}…")
    try:
        leads = await services.two_gis.search(city, category, limit)
    except Exception as exc:
        logger.exception("2GIS search failed")
        await status.edit_text(f"Ошибка поиска 2ГИС: <code>{html.escape(str(exc))}</code>")
        return
    new_records = []
    for lead in leads:
        record = await services.repository.add_lead(lead)
        if record:
            new_records.append(record)
    await status.edit_text(
        f"Найдено подходящих компаний: {len(leads)}. Новых в базе: {len(new_records)}."
        + (" Проверьте доступ ключа к контактам, если результатов нет." if not leads else "")
    )
    for record in new_records:
        await message.answer(lead_card(record), reply_markup=lead_keyboard(record.id, record.source_url))


@router.message(Command("stats"))
@router.message(F.text == "📊 Статистика")
async def stats(message: Message, services: AppServices) -> None:
    if not authorized(message.from_user.id, services):
        await deny(message)
        return
    data = await services.repository.stats()
    await message.answer(
        "<b>Статистика</b>\n\n"
        f"Заданий обработано: {data['task_total']}\n"
        f"Новых заданий: {data['task_new']}\n"
        f"Компаний найдено: {data['lead_total']}\n"
        f"Новых лидов: {data['lead_new']}"
    )


@router.message(Command("status"))
@router.message(F.text == "⚙️ Проверка настройки")
async def settings_status(message: Message, services: AppServices) -> None:
    if not authorized(message.from_user.id, services):
        await deny(message)
        return
    s = services.settings
    await message.answer(
        "<b>Подключения</b>\n\n"
        f"OpenAI: {'✅' if s.openai_api_key else '⚠️ шаблонный режим'}\n"
        f"Email Kwork/YouDo: {'✅' if s.imap_enabled else '⏸ выключен'}\n"
        f"2ГИС: {'✅' if s.two_gis_api_key else '⏸ ключ не задан'}\n"
        f"Владельцы: {'✅' if s.telegram_admin_ids else '⚠️ ограничение не настроено'}"
    )


@router.callback_query(F.data.startswith("task_reply:"))
async def task_reply(callback: CallbackQuery, services: AppServices) -> None:
    if not authorized(callback.from_user.id, services):
        await callback.answer("Нет доступа", show_alert=True)
        return
    task_id = int(callback.data.split(":", 1)[1])
    record = await services.repository.get_task(task_id)
    if not record:
        await callback.answer("Задание не найдено", show_alert=True)
        return
    await callback.message.answer(f"<b>Готовый отклик:</b>\n\n<code>{html.escape(record.reply)}</code>")
    await callback.answer()


@router.callback_query(F.data.startswith("task_price:"))
async def task_price(callback: CallbackQuery, services: AppServices) -> None:
    if not authorized(callback.from_user.id, services):
        await callback.answer("Нет доступа", show_alert=True)
        return
    task_id = int(callback.data.split(":", 1)[1])
    record = await services.repository.get_task(task_id)
    if not record:
        await callback.answer("Задание не найдено", show_alert=True)
        return
    await callback.message.answer(
        f"Цена для отклика: <code>{money(record.recommended_price)}</code>\n"
        f"Оценка прямой рыночной стоимости: {money(record.market_price)}"
    )
    await callback.answer()


@router.callback_query(F.data.startswith("task_done:"))
async def task_done(callback: CallbackQuery, services: AppServices) -> None:
    task_id = int(callback.data.split(":", 1)[1])
    await services.repository.set_task_status(task_id, "applied")
    await callback.answer("Отмечено: отклик отправлен")


@router.callback_query(F.data.startswith("task_skip:"))
async def task_skip(callback: CallbackQuery, services: AppServices) -> None:
    task_id = int(callback.data.split(":", 1)[1])
    await services.repository.set_task_status(task_id, "skipped")
    await callback.answer("Задание пропущено")


@router.callback_query(F.data.startswith("lead_message:"))
async def lead_message(callback: CallbackQuery, services: AppServices) -> None:
    if not authorized(callback.from_user.id, services):
        await callback.answer("Нет доступа", show_alert=True)
        return
    lead_id = int(callback.data.split(":", 1)[1])
    record = await services.repository.get_lead(lead_id)
    if not record:
        await callback.answer("Компания не найдена", show_alert=True)
        return
    try:
        phones = json.loads(record.phones or "[]")
    except json.JSONDecodeError:
        phones = []
    await callback.message.answer(
        f"<b>Телефон:</b> <code>{html.escape(', '.join(phones))}</code>\n"
        f"<b>Сообщение:</b>\n\n<code>{html.escape(record.message)}</code>\n\n"
        f"Ориентир стоимости: <code>{money(record.recommended_price)}</code>"
    )
    await callback.answer()


@router.callback_query(F.data.startswith("lead_contacted:"))
async def lead_contacted(callback: CallbackQuery, services: AppServices) -> None:
    lead_id = int(callback.data.split(":", 1)[1])
    await services.repository.set_lead_status(lead_id, "contacted")
    await callback.answer("Отмечено: связались")


@router.callback_query(F.data.startswith("lead_skip:"))
async def lead_skip(callback: CallbackQuery, services: AppServices) -> None:
    lead_id = int(callback.data.split(":", 1)[1])
    await services.repository.set_lead_status(lead_id, "skipped")
    await callback.answer("Компания пропущена")
