from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import DateTime, Float, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from app.db import Base


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class TaskRecord(Base):
    __tablename__ = "tasks"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    source: Mapped[str] = mapped_column(String(30), index=True)
    external_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    title: Mapped[str] = mapped_column(String(500))
    description: Mapped[str] = mapped_column(Text)
    budget: Mapped[int | None] = mapped_column(Integer, nullable=True)
    url: Mapped[str | None] = mapped_column(Text, nullable=True)
    raw_text: Mapped[str] = mapped_column(Text, default="")
    relevance_score: Mapped[int] = mapped_column(Integer, default=0)
    project_type: Mapped[str] = mapped_column(String(50), default="business_site")
    complexity: Mapped[str] = mapped_column(String(20), default="medium")
    market_price: Mapped[int] = mapped_column(Integer, default=0)
    recommended_price: Mapped[int] = mapped_column(Integer, default=0)
    deadline_days: Mapped[int] = mapped_column(Integer, default=5)
    reply: Mapped[str] = mapped_column(Text, default="")
    reasoning_summary: Mapped[str] = mapped_column(Text, default="")
    risk_flags: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(30), default="new", index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    __table_args__ = (UniqueConstraint("source", "external_id", name="uq_task_source_external"),)


class LeadRecord(Base):
    __tablename__ = "leads"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    two_gis_id: Mapped[str] = mapped_column(String(255), unique=True)
    company: Mapped[str] = mapped_column(String(500))
    city: Mapped[str] = mapped_column(String(255))
    category: Mapped[str] = mapped_column(String(255))
    phones: Mapped[str] = mapped_column(Text, default="")
    website: Mapped[str | None] = mapped_column(Text, nullable=True)
    issue: Mapped[str] = mapped_column(String(255), default="Сайт не указан")
    recommended_price: Mapped[int] = mapped_column(Integer)
    message: Mapped[str] = mapped_column(Text)
    source_url: Mapped[str] = mapped_column(Text)
    rating: Mapped[float | None] = mapped_column(Float, nullable=True)
    review_count: Mapped[int | None] = mapped_column(Integer, nullable=True)
    status: Mapped[str] = mapped_column(String(30), default="new", index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class SeenEmail(Base):
    __tablename__ = "seen_emails"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    mailbox: Mapped[str] = mapped_column(String(255))
    uid: Mapped[str] = mapped_column(String(255))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    __table_args__ = (UniqueConstraint("mailbox", "uid", name="uq_seen_email"),)
