from __future__ import annotations

import json

from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError

from app.db import Database
from app.models import LeadRecord, SeenEmail, TaskRecord
from app.schemas import LeadResult, ParsedTask, ProposalResult


class Repository:
    def __init__(self, db: Database):
        self.db = db

    async def add_task(self, task: ParsedTask, proposal: ProposalResult) -> TaskRecord | None:
        record = TaskRecord(
            source=task.source,
            external_id=task.external_id,
            title=task.title[:500],
            description=task.description,
            budget=task.budget,
            url=task.url,
            raw_text=task.raw_text,
            relevance_score=proposal.relevance_score,
            project_type=proposal.project_type,
            complexity=proposal.complexity,
            market_price=proposal.market_price,
            recommended_price=proposal.recommended_price,
            deadline_days=proposal.deadline_days,
            reply=proposal.reply,
            reasoning_summary=proposal.reasoning_summary,
            risk_flags=json.dumps(proposal.risk_flags, ensure_ascii=False),
        )
        async with self.db.session_factory() as session:
            session.add(record)
            try:
                await session.commit()
            except IntegrityError:
                await session.rollback()
                return None
            await session.refresh(record)
            return record

    async def get_task(self, task_id: int) -> TaskRecord | None:
        async with self.db.session_factory() as session:
            return await session.get(TaskRecord, task_id)

    async def set_task_status(self, task_id: int, status: str) -> None:
        async with self.db.session_factory() as session:
            record = await session.get(TaskRecord, task_id)
            if record:
                record.status = status
                await session.commit()

    async def add_lead(self, lead: LeadResult) -> LeadRecord | None:
        record = LeadRecord(
            two_gis_id=lead.two_gis_id,
            company=lead.company,
            city=lead.city,
            category=lead.category,
            phones=json.dumps(lead.phones, ensure_ascii=False),
            website=lead.website,
            issue=lead.issue,
            recommended_price=lead.recommended_price,
            message=lead.message,
            source_url=lead.source_url,
            rating=lead.rating,
            review_count=lead.review_count,
        )
        async with self.db.session_factory() as session:
            session.add(record)
            try:
                await session.commit()
            except IntegrityError:
                await session.rollback()
                return None
            await session.refresh(record)
            return record

    async def get_lead(self, lead_id: int) -> LeadRecord | None:
        async with self.db.session_factory() as session:
            return await session.get(LeadRecord, lead_id)

    async def set_lead_status(self, lead_id: int, status: str) -> None:
        async with self.db.session_factory() as session:
            record = await session.get(LeadRecord, lead_id)
            if record:
                record.status = status
                await session.commit()

    async def email_seen(self, mailbox: str, uid: str) -> bool:
        async with self.db.session_factory() as session:
            stmt = select(SeenEmail.id).where(SeenEmail.mailbox == mailbox, SeenEmail.uid == uid)
            return (await session.execute(stmt)).scalar_one_or_none() is not None

    async def mark_email_seen(self, mailbox: str, uid: str) -> None:
        async with self.db.session_factory() as session:
            session.add(SeenEmail(mailbox=mailbox, uid=uid))
            try:
                await session.commit()
            except IntegrityError:
                await session.rollback()

    async def stats(self) -> dict[str, int]:
        async with self.db.session_factory() as session:
            task_total = (await session.execute(select(func.count(TaskRecord.id)))).scalar_one()
            task_new = (
                await session.execute(select(func.count(TaskRecord.id)).where(TaskRecord.status == "new"))
            ).scalar_one()
            lead_total = (await session.execute(select(func.count(LeadRecord.id)))).scalar_one()
            lead_new = (
                await session.execute(select(func.count(LeadRecord.id)).where(LeadRecord.status == "new"))
            ).scalar_one()
        return {
            "task_total": int(task_total),
            "task_new": int(task_new),
            "lead_total": int(lead_total),
            "lead_new": int(lead_new),
        }
