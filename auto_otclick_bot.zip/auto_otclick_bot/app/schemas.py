from __future__ import annotations

from pydantic import BaseModel, Field


class ParsedTask(BaseModel):
    source: str = "manual"
    external_id: str | None = None
    title: str = "Новое задание"
    description: str
    budget: int | None = None
    url: str | None = None
    raw_text: str = ""


class ProposalResult(BaseModel):
    relevance_score: int = Field(default=70, ge=0, le=100)
    project_type: str = "business_site"
    complexity: str = "medium"
    market_price: int = 0
    recommended_price: int = 0
    deadline_days: int = 5
    reply: str
    reasoning_summary: str = ""
    risk_flags: list[str] = Field(default_factory=list)


class LeadResult(BaseModel):
    two_gis_id: str
    company: str
    city: str
    category: str
    phones: list[str] = Field(default_factory=list)
    website: str | None = None
    issue: str = "Сайт не указан"
    recommended_price: int
    message: str
    source_url: str
    rating: float | None = None
    review_count: int | None = None
