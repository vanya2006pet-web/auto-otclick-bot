from __future__ import annotations

import time
from dataclasses import dataclass
from urllib.parse import urlparse

import httpx
from bs4 import BeautifulSoup


@dataclass(slots=True)
class WebsiteAudit:
    reachable: bool
    issue: str | None
    status_code: int | None = None
    response_ms: int | None = None


class WebsiteAuditor:
    def __init__(self):
        self.client = httpx.AsyncClient(
            timeout=httpx.Timeout(12.0, connect=6.0),
            follow_redirects=True,
            headers={"User-Agent": "Mozilla/5.0 (compatible; SiteLeadAudit/1.0)"},
        )

    async def close(self) -> None:
        await self.client.aclose()

    async def audit(self, url: str) -> WebsiteAudit:
        normalized = self._normalize(url)
        started = time.perf_counter()
        try:
            response = await self.client.get(normalized)
            elapsed = int((time.perf_counter() - started) * 1000)
            if response.status_code >= 400:
                return WebsiteAudit(False, f"Сайт отвечает с ошибкой {response.status_code}", response.status_code, elapsed)
            soup = BeautifulSoup(response.text[:500000], "html.parser")
            viewport = soup.find("meta", attrs={"name": lambda value: value and value.lower() == "viewport"})
            if not viewport:
                return WebsiteAudit(True, "Не обнаружена мобильная адаптация", response.status_code, elapsed)
            if elapsed > 5000:
                return WebsiteAudit(True, "Сайт загружается медленно", response.status_code, elapsed)
            if urlparse(str(response.url)).scheme != "https":
                return WebsiteAudit(True, "Сайт работает без HTTPS", response.status_code, elapsed)
            return WebsiteAudit(True, None, response.status_code, elapsed)
        except httpx.HTTPError:
            elapsed = int((time.perf_counter() - started) * 1000)
            return WebsiteAudit(False, "Сайт не открывается", None, elapsed)

    @staticmethod
    def _normalize(url: str) -> str:
        url = url.strip()
        if not url.startswith(("http://", "https://")):
            return f"https://{url}"
        return url
