from __future__ import annotations

import json
import logging
import re

import httpx

from app.prompts import SYSTEM_PROMPT
from app.schemas import ParsedTask, ProposalResult
from app.services.pricing import PricingService

logger = logging.getLogger(__name__)


class AIService:
    def __init__(self, api_key: str, model: str, pricing: PricingService):
        self.api_key = api_key
        self.model = model
        self.pricing = pricing
        self.client = httpx.AsyncClient(timeout=httpx.Timeout(45.0, connect=15.0))

    async def close(self) -> None:
        await self.client.aclose()

    async def analyze_task(self, task: ParsedTask) -> ProposalResult:
        project_type = self.pricing.classify(f"{task.title}\n{task.description}")
        complexity = self.pricing.complexity(task.description)
        price = self.pricing.calculate_platform(project_type, complexity, task.budget)
        if not self.api_key:
            return self._fallback(task, project_type, complexity, price)

        prompt = self._user_prompt(task, project_type, complexity, price)
        try:
            response = await self.client.post(
                "https://api.openai.com/v1/responses",
                headers={"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"},
                json={
                    "model": self.model,
                    "reasoning": {"effort": "low"},
                    "input": [
                        {"role": "system", "content": [{"type": "input_text", "text": SYSTEM_PROMPT}]},
                        {"role": "user", "content": [{"type": "input_text", "text": prompt}]},
                    ],
                },
            )
            response.raise_for_status()
            output_text = self._extract_output_text(response.json())
            data = self._extract_json(output_text)
            result = ProposalResult.model_validate(data)
            result.project_type = project_type
            result.complexity = complexity
            result.market_price = price["market_price"]
            result.recommended_price = price["recommended_price"]
            result.deadline_days = max(1, min(60, result.deadline_days or price["deadline_days"]))
            result.reply = self._ensure_price_and_length(result.reply, price["recommended_price"], result.deadline_days)
            return result
        except Exception as exc:
            logger.exception("OpenAI analysis failed: %s", exc)
            return self._fallback(task, project_type, complexity, price)

    def _user_prompt(self, task: ParsedTask, project_type: str, complexity: str, price: dict[str, int]) -> str:
        return f"""
Источник: {task.source}
Название: {task.title}
Описание:
{task.description[:10000]}
Бюджет заказчика: {task.budget or 'не указан'} ₽
Тип проекта, определённый системой: {project_type}
Сложность: {complexity}
Рассчитанная цена отклика: {price['recommended_price']} ₽
Базовый срок: {price['deadline_days']} дней

Верни JSON строго такой структуры:
{{
  "relevance_score": 0,
  "project_type": "{project_type}",
  "complexity": "{complexity}",
  "market_price": {price['market_price']},
  "recommended_price": {price['recommended_price']},
  "deadline_days": {price['deadline_days']},
  "reply": "короткий персональный отклик",
  "reasoning_summary": "почему задание подходит или не подходит",
  "risk_flags": ["риски и неясности"]
}}
""".strip()

    def _fallback(self, task: ParsedTask, project_type: str, complexity: str, price: dict[str, int]) -> ProposalResult:
        label = self.pricing.project_label(project_type).lower()
        detail = self._task_detail(task.description)
        reply = (
            f"Добрый день. Разработаю {label} под вашу задачу{detail}. "
            f"Сначала согласуем структуру и ключевые функции, затем покажу рабочий вариант. "
            f"Стоимость — {price['recommended_price']:,} ₽, срок — {price['deadline_days']} дн. "
            "Можно прислать исходные материалы и требования к результату?"
        ).replace(",", " ")
        relevance = 85 if project_type != "business_site" or any(k in task.description.lower() for k in ("сайт", "бот", "прилож", "api")) else 65
        return ProposalResult(
            relevance_score=relevance,
            project_type=project_type,
            complexity=complexity,
            market_price=price["market_price"],
            recommended_price=price["recommended_price"],
            deadline_days=price["deadline_days"],
            reply=reply[:500],
            reasoning_summary="Задание соответствует разработке цифрового продукта; цена рассчитана по типу и сложности.",
            risk_flags=self._risk_flags(task.description),
        )

    @staticmethod
    def _task_detail(text: str) -> str:
        lowered = text.lower()
        details = []
        if "дизайн" in lowered or "figma" in lowered:
            details.append(" по вашему дизайну")
        if "адаптив" in lowered or "мобиль" in lowered:
            details.append(" с адаптацией под телефоны")
        if "api" in lowered or "интеграц" in lowered:
            details.append(" с требуемой интеграцией")
        return "".join(details[:2])

    @staticmethod
    def _risk_flags(text: str) -> list[str]:
        lowered = text.lower()
        risks = []
        if len(text) < 120:
            risks.append("Недостаточно подробное описание")
        if "срочно" in lowered or "сегодня" in lowered:
            risks.append("Срочный срок")
        if "оплата после" in lowered or "без предоплаты" in lowered:
            risks.append("Риск условий оплаты")
        return risks

    @staticmethod
    def _extract_output_text(payload: dict) -> str:
        if isinstance(payload.get("output_text"), str):
            return payload["output_text"]
        chunks: list[str] = []
        for item in payload.get("output", []):
            for content in item.get("content", []):
                text = content.get("text")
                if isinstance(text, str):
                    chunks.append(text)
        if not chunks:
            raise ValueError("OpenAI response contains no text")
        return "\n".join(chunks)

    @staticmethod
    def _extract_json(text: str) -> dict:
        text = text.strip()
        if text.startswith("```"):
            text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.IGNORECASE)
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            start = text.find("{")
            end = text.rfind("}")
            if start == -1 or end == -1:
                raise
            return json.loads(text[start : end + 1])

    @staticmethod
    def _ensure_price_and_length(reply: str, price: int, days: int) -> str:
        cleaned = re.sub(r"\s+", " ", reply).strip()
        if str(price) not in cleaned and f"{price:,}".replace(",", " ") not in cleaned:
            cleaned += f" Стоимость — {price:,} ₽, срок — {days} дн.".replace(",", " ")
        return cleaned[:500]
