from __future__ import annotations

import logging

from aiogram import Bot

from app.bot.keyboards import task_keyboard
from app.bot.presenters import task_card
from app.models import TaskRecord

logger = logging.getLogger(__name__)


class TelegramNotifier:
    def __init__(self, bot: Bot, admin_ids: list[int]):
        self.bot = bot
        self.admin_ids = admin_ids

    async def task(self, record: TaskRecord) -> None:
        if not self.admin_ids:
            logger.warning("Cannot notify about email task: TELEGRAM_ADMIN_IDS is empty")
            return
        for admin_id in self.admin_ids:
            try:
                await self.bot.send_message(
                    admin_id,
                    task_card(record),
                    reply_markup=task_keyboard(record.id, record.url),
                )
            except Exception:
                logger.exception("Failed to notify Telegram admin %s", admin_id)
