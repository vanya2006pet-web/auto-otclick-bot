from __future__ import annotations

import hashlib
import re
from email.message import Message
from html import unescape
from urllib.parse import urlparse

from bs4 import BeautifulSoup

from app.schemas import ParsedTask


MONEY_RE = re.compile(r"(?<!\d)(\d[\d\s\u00a0]{2,8})\s*(?:₽|руб(?:лей|ля|ль)?|р\.?)(?!\w)", re.IGNORECASE)
URL_RE = re.compile(r"https?://[^\s<>\"']+")


class TaskParser:
    def parse_manual(self, text: str) -> ParsedTask:
        cleaned = text.strip()
        lines = [line.strip() for line in cleaned.splitlines() if line.strip()]
        title = lines[0][:180] if lines else "Новое задание"
        budget = self._extract_budget(cleaned)
        url = self._best_url(cleaned, "manual")
        return ParsedTask(
            source=self._detect_source(cleaned),
            external_id=hashlib.sha256(cleaned.encode("utf-8")).hexdigest()[:24],
            title=title,
            description=cleaned,
            budget=budget,
            url=url,
            raw_text=cleaned,
        )

    def parse_email(self, message: Message, uid: str) -> ParsedTask | None:
        subject = self._decode_header(message.get("Subject", ""))
        sender = self._decode_header(message.get("From", ""))
        body = self._message_text(message)
        combined = f"{subject}\n{body}".strip()
        source = self._detect_source(f"{sender}\n{combined}")
        if source not in {"kwork", "youdo"}:
            return None
        description = self._clean_body(body)
        return ParsedTask(
            source=source,
            external_id=f"email-{uid}",
            title=subject[:500] or "Новое задание",
            description=description[:12000],
            budget=self._extract_budget(combined),
            url=self._best_url(combined, source),
            raw_text=combined[:20000],
        )

    @staticmethod
    def _decode_header(value: str) -> str:
        from email.header import decode_header, make_header

        try:
            return str(make_header(decode_header(value)))
        except Exception:
            return value

    def _message_text(self, message: Message) -> str:
        plain_parts: list[str] = []
        html_parts: list[str] = []
        if message.is_multipart():
            for part in message.walk():
                content_type = part.get_content_type()
                disposition = str(part.get("Content-Disposition", ""))
                if "attachment" in disposition:
                    continue
                payload = self._decode_payload(part)
                if content_type == "text/plain":
                    plain_parts.append(payload)
                elif content_type == "text/html":
                    html_parts.append(payload)
        else:
            payload = self._decode_payload(message)
            if message.get_content_type() == "text/html":
                html_parts.append(payload)
            else:
                plain_parts.append(payload)
        if plain_parts:
            return "\n".join(plain_parts)
        html = "\n".join(html_parts)
        return BeautifulSoup(html, "html.parser").get_text("\n")

    @staticmethod
    def _decode_payload(part: Message) -> str:
        payload = part.get_payload(decode=True)
        if payload is None:
            return str(part.get_payload())
        charset = part.get_content_charset() or "utf-8"
        try:
            return payload.decode(charset, errors="replace")
        except LookupError:
            return payload.decode("utf-8", errors="replace")

    @staticmethod
    def _clean_body(text: str) -> str:
        text = unescape(text)
        lines = [re.sub(r"\s+", " ", line).strip() for line in text.splitlines()]
        lines = [line for line in lines if line]
        return "\n".join(lines)

    @staticmethod
    def _detect_source(text: str) -> str:
        lowered = text.lower()
        if "kwork" in lowered or "кворк" in lowered:
            return "kwork"
        if "youdo" in lowered or "юду" in lowered:
            return "youdo"
        return "manual"

    @staticmethod
    def _extract_budget(text: str) -> int | None:
        values: list[int] = []
        for match in MONEY_RE.finditer(text):
            raw = re.sub(r"\D", "", match.group(1))
            if raw:
                value = int(raw)
                if 300 <= value <= 50_000_000:
                    values.append(value)
        return max(values) if values else None

    def _best_url(self, text: str, source: str) -> str | None:
        urls = [url.rstrip(".,);]") for url in URL_RE.findall(text)]
        if not urls:
            return None
        preferred_domains = {"kwork": "kwork.ru", "youdo": "youdo.com"}
        preferred = preferred_domains.get(source)
        if preferred:
            for url in urls:
                if preferred in urlparse(url).netloc.lower():
                    return url
        return urls[0]
