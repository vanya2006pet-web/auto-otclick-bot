from __future__ import annotations

from dataclasses import dataclass

from app.config import Settings
from app.repositories import Repository
from app.services.ai import AIService
from app.services.email_monitor import EmailMonitor
from app.services.pricing import PricingService
from app.services.task_parser import TaskParser
from app.services.two_gis import TwoGisService
from app.services.website_audit import WebsiteAuditor


@dataclass(slots=True)
class AppServices:
    settings: Settings
    repository: Repository
    pricing: PricingService
    parser: TaskParser
    ai: AIService
    email_monitor: EmailMonitor
    two_gis: TwoGisService
    website_auditor: WebsiteAuditor

    async def close(self) -> None:
        await self.ai.close()
        await self.two_gis.close()
        await self.website_auditor.close()
