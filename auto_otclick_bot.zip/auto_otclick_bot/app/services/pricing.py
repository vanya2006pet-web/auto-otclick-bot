from __future__ import annotations

import math
from pathlib import Path

import yaml


PROJECT_KEYWORDS: list[tuple[str, tuple[str, ...]]] = [
    ("mobile_app", ("мобильн", "android", "ios", "приложение для телефона", "flutter", "react native")),
    ("ecommerce", ("интернет-магазин", "магазин", "корзин", "каталог товаров", "оплата на сайте")),
    ("telegram_bot", ("telegram", "телеграм", "тг бот", "чат-бот", "бот для", "бота для", "создать бота", "разработать бота")),
    ("web_app", ("веб-прилож", "личный кабинет", "crm", "saas", "панель управления", "dashboard")),
    ("automation", ("автоматизац", "парсер", "интеграц", "api", "скрипт", "выгрузк", "обмен данными")),
    ("corporate_site", ("корпоративн", "многостранич", "сайт компании", "сайт организации")),
    ("landing", ("лендинг", "landing", "одностранич", "посадочн")),
    ("page_layout", ("верстк", "сверстать", "html", "css", "макет figma")),
    ("design", ("дизайн сайта", "ui", "ux", "figma", "макет сайта")),
    ("small_fix", ("доработ", "исправить", "починить", "баг", "правк", "не работает")),
]

HIGH_COMPLEXITY = (
    "личный кабинет",
    "платеж",
    "эквайринг",
    "маркетплейс",
    "много ролей",
    "геолокац",
    "видеозвон",
    "нейросет",
    "реальное время",
    "websocket",
)
LOW_COMPLEXITY = ("небольш", "прост", "одна страница", "пара правок", "готовый дизайн")


class PricingService:
    def __init__(self, config_path: Path):
        with config_path.open("r", encoding="utf-8") as file:
            self.config = yaml.safe_load(file)

    def classify(self, text: str) -> str:
        lowered = text.lower()
        for project_type, keywords in PROJECT_KEYWORDS:
            if any(keyword in lowered for keyword in keywords):
                return project_type
        return "business_site"

    def complexity(self, text: str) -> str:
        lowered = text.lower()
        high_hits = sum(keyword in lowered for keyword in HIGH_COMPLEXITY)
        low_hits = sum(keyword in lowered for keyword in LOW_COMPLEXITY)
        if high_hits >= 2 or len(text) > 3000:
            return "high"
        if low_hits >= 1 and high_hits == 0:
            return "low"
        return "medium"

    def calculate_platform(self, project_type: str, complexity: str, budget: int | None) -> dict[str, int]:
        project = self.config["project_types"].get(project_type, self.config["project_types"]["business_site"])
        factor = float(self.config["complexity_factors"].get(complexity, 1.0))
        market = int(project["direct_market"] * factor)
        floor = int(project["platform_floor"])
        proposed = max(floor, int(market * float(project["platform_factor"])))
        if budget and budget > 0:
            proposed = min(proposed, max(floor, int(budget * float(self.config["platform_budget_cap"]))))
        proposed = self._round(proposed)
        days = max(1, int(math.ceil(float(project["default_days"]) * factor)))
        return {"market_price": self._round(market), "recommended_price": proposed, "deadline_days": days}

    def direct_lead_price(self, category: str) -> int:
        lowered = category.lower()
        prices = self.config.get("direct_lead_prices", {})
        for keyword, price in prices.items():
            if keyword != "default" and keyword in lowered:
                return self._round(int(price))
        return self._round(int(prices.get("default", 55000)))

    def project_label(self, project_type: str) -> str:
        project = self.config["project_types"].get(project_type, {})
        return str(project.get("label", "Разработка"))

    def _round(self, value: int) -> int:
        step = int(self.config.get("round_to", 500))
        return max(step, int(round(value / step) * step))
