from __future__ import annotations

import asyncio
import email
import imaplib
import logging
from dataclasses import dataclass
from email.message import Message

from app.config import Settings
from app.repositories import Repository
from app.services.task_parser import TaskParser

logger = logging.getLogger(__name__)


@dataclass(slots=True)
class EmailTask:
    uid: str
    message: Message


class EmailMonitor:
    def __init__(self, settings: Settings, repository: Repository, parser: TaskParser):
        self.settings = settings
        self.repository = repository
        self.parser = parser

    async def fetch_new(self) -> list[tuple[str, object]]:
        if not self.settings.imap_enabled:
            return []
        messages = await asyncio.to_thread(self._fetch_sync)
        parsed = []
        mailbox = self.settings.imap_username
        for item in messages:
            if await self.repository.email_seen(mailbox, item.uid):
                continue
            task = self.parser.parse_email(item.message, item.uid)
            await self.repository.mark_email_seen(mailbox, item.uid)
            if task:
                parsed.append((item.uid, task))
        return parsed

    def _fetch_sync(self) -> list[EmailTask]:
        settings = self.settings
        if not all((settings.imap_host, settings.imap_username, settings.imap_password)):
            raise RuntimeError("IMAP включён, но реквизиты почты не заполнены")
        client = imaplib.IMAP4_SSL(settings.imap_host, settings.imap_port)
        try:
            client.login(settings.imap_username, settings.imap_password)
            status, _ = client.select(settings.imap_folder)
            if status != "OK":
                raise RuntimeError(f"Не удалось открыть папку {settings.imap_folder}")
            status, data = client.uid("search", None, "UNSEEN")
            if status != "OK" or not data:
                return []
            uids = data[0].split()[-settings.max_tasks_per_email_poll :]
            output: list[EmailTask] = []
            for raw_uid in uids:
                uid = raw_uid.decode("ascii", errors="ignore")
                status, parts = client.uid("fetch", raw_uid, "(RFC822)")
                if status != "OK":
                    continue
                raw_message = next((part[1] for part in parts if isinstance(part, tuple)), None)
                if raw_message:
                    output.append(EmailTask(uid=uid, message=email.message_from_bytes(raw_message)))
            return output
        finally:
            try:
                client.logout()
            except Exception:
                logger.debug("IMAP logout failed", exc_info=True)
