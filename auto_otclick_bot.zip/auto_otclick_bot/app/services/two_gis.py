from __future__ import annotations

import logging
from urllib.parse import quote

import httpx

from app.schemas import LeadResult
from app.services.pricing import PricingService
from app.services.website_audit import WebsiteAuditor

logger = logging.getLogger(__name__)


class TwoGisService:
    BASE_URL = "https://catalog.api.2gis.com/3.0/items"

    def __init__(
        self,
        api_key: str,
        page_size: int,
        max_pages: int,
        only_without_website: bool,
        pricing: PricingService,
        auditor: WebsiteAuditor,
    ):
        self.api_key = api_key
        self.page_size = min(max(page_size, 1), 50)
        self.max_pages = min(max(max_pages, 1), 20)
        self.only_without_website = only_without_website
        self.pricing = pricing
        self.auditor = auditor
        self.client = httpx.AsyncClient(timeout=httpx.Timeout(25.0, connect=10.0))

    async def close(self) -> None:
        await self.client.aclose()

    async def search(self, city: str, category: str, limit: int) -> list[LeadResult]:
        if not self.api_key:
            raise RuntimeError("Не указан TWO_GIS_API_KEY")
        results: list[LeadResult] = []
        for page in range(1, self.max_pages + 1):
            params = {
                "q": f"{city} {category}",
                "type": "branch",
                "page": page,
                "page_size": self.page_size,
                "key": self.api_key,
                "fields": "items.contact_groups,items.rubrics,items.reviews,items.address_name,items.point",
            }
            response = await self.client.get(self.BASE_URL, params=params)
            response.raise_for_status()
            payload = response.json()
            items = payload.get("result", {}).get("items", [])
            if not items:
                break
            for item in items:
                lead = await self._to_lead(item, city, category)
                if lead:
                    results.append(lead)
                    if len(results) >= limit:
                        return results
        return results

    async def _to_lead(self, item: dict, city: str, category: str) -> LeadResult | None:
        contacts = self._contacts(item)
        phones = contacts["phones"]
        websites = contacts["websites"]
        if not phones:
            return None

        website = websites[0] if websites else None
        issue = "Сайт не указан"
        if website:
            if self.only_without_website:
                return None
            audit = await self.auditor.audit(website)
            if not audit.issue:
                return None
            issue = audit.issue

        company = str(item.get("name") or "Компания").strip()
        price = self.pricing.direct_lead_price(category)
        message = self._message(company, issue)
        reviews = item.get("reviews") or {}
        item_id = str(item.get("id") or item.get("org_id") or f"{company}-{city}")
        source_url = f"https://2gis.ru/search/{quote(company + ' ' + city)}"
        return LeadResult(
            two_gis_id=item_id,
            company=company,
            city=city,
            category=category,
            phones=phones,
            website=website,
            issue=issue,
            recommended_price=price,
            message=message,
            source_url=source_url,
            rating=self._float_or_none(reviews.get("general_rating")),
            review_count=self._int_or_none(reviews.get("general_review_count")),
        )

    @staticmethod
    def _contacts(item: dict) -> dict[str, list[str]]:
        phones: list[str] = []
        websites: list[str] = []
        for group in item.get("contact_groups") or []:
            for contact in group.get("contacts") or []:
                contact_type = str(contact.get("type") or "").lower()
                value = str(contact.get("value") or contact.get("text") or "").strip()
                if not value:
                    continue
                if contact_type in {"phone", "tel"}:
                    phones.append(value)
                elif contact_type in {"website", "url", "site"}:
                    websites.append(value)
        return {"phones": list(dict.fromkeys(phones)), "websites": list(dict.fromkeys(websites))}

    @staticmethod
    def _message(company: str, issue: str) -> str:
        if issue == "Сайт не указан":
            return (
                f"Добрый день. Увидел, что у «{company}» нет собственного сайта. "
                "Могу сделать современный сайт с услугами и формой заявки. Показать вариант первого экрана?"
            )[:300]
        return (
            f"Добрый день. Посмотрел сайт «{company}»: {issue.lower()}. "
            "Могу обновить его и сделать удобнее для заявок с телефона. Показать вариант первого экрана?"
        )[:300]

    @staticmethod
    def _float_or_none(value: object) -> float | None:
        try:
            return float(value) if value is not None else None
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _int_or_none(value: object) -> int | None:
        try:
            return int(value) if value is not None else None
        except (TypeError, ValueError):
            return None
