from __future__ import annotations

import asyncio
import contextlib
import logging
from contextlib import asynccontextmanager

import uvicorn
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import Update
from fastapi import FastAPI, HTTPException, Request

from app.bot.router import router
from app.config import get_settings
from app.db import Database
from app.logging_config import configure_logging
from app.repositories import Repository
from app.services.ai import AIService
from app.services.container import AppServices
from app.services.email_monitor import EmailMonitor
from app.services.notifier import TelegramNotifier
from app.services.pricing import PricingService
from app.services.task_parser import TaskParser
from app.services.two_gis import TwoGisService
from app.services.website_audit import WebsiteAuditor

settings = get_settings()
configure_logging(settings.log_level)
logger = logging.getLogger(__name__)


async def email_worker(services: AppServices, notifier: TelegramNotifier) -> None:
    while True:
        try:
            tasks = await services.email_monitor.fetch_new()
            for _, parsed_task in tasks:
                proposal = await services.ai.analyze_task(parsed_task)
                record = await services.repository.add_task(parsed_task, proposal)
                if record:
                    await notifier.task(record)
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("Email worker iteration failed")
        await asyncio.sleep(max(30, services.settings.email_poll_seconds))


@asynccontextmanager
async def lifespan(app: FastAPI):
    database = Database(settings.database_url)
    await database.init()
    repository = Repository(database)
    pricing = PricingService(settings.prices_path)
    parser = TaskParser()
    auditor = WebsiteAuditor()
    ai = AIService(settings.openai_api_key, settings.openai_model, pricing)
    two_gis = TwoGisService(
        settings.two_gis_api_key,
        settings.two_gis_page_size,
        settings.two_gis_max_pages,
        settings.two_gis_only_without_website,
        pricing,
        auditor,
    )
    email_monitor = EmailMonitor(settings, repository, parser)
    services = AppServices(settings, repository, pricing, parser, ai, email_monitor, two_gis, auditor)
    app.state.services = services
    app.state.database = database

    tasks: list[asyncio.Task] = []
    bot: Bot | None = None
    dispatcher: Dispatcher | None = None
    if settings.telegram_bot_token:
        bot = Bot(settings.telegram_bot_token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
        dispatcher = Dispatcher(storage=MemoryStorage())
        dispatcher.include_router(router)
        app.state.bot = bot
        app.state.dispatcher = dispatcher
        notifier = TelegramNotifier(bot, settings.telegram_admin_ids)

        if settings.telegram_mode.lower() == "webhook":
            if not settings.telegram_webhook_base_url:
                raise RuntimeError("TELEGRAM_MODE=webhook, но TELEGRAM_WEBHOOK_BASE_URL не указан")
            webhook_url = settings.telegram_webhook_base_url.rstrip("/") + "/telegram/webhook"
            await bot.set_webhook(
                webhook_url,
                secret_token=settings.telegram_webhook_secret or None,
                allowed_updates=dispatcher.resolve_used_update_types(),
            )
            logger.info("Telegram webhook configured: %s", webhook_url)
        else:
            await bot.delete_webhook(drop_pending_updates=False)
            tasks.append(asyncio.create_task(dispatcher.start_polling(bot, services=services), name="telegram-polling"))

        if settings.imap_enabled:
            tasks.append(asyncio.create_task(email_worker(services, notifier), name="email-monitor"))
    else:
        logger.error("TELEGRAM_BOT_TOKEN is empty; Telegram bot is not started")

    try:
        yield
    finally:
        for task in tasks:
            task.cancel()
        for task in tasks:
            with contextlib.suppress(asyncio.CancelledError):
                await task
        if bot:
            await bot.session.close()
        await services.close()
        await database.dispose()


app = FastAPI(title="Auto Otclick Bot", version="1.0.0", lifespan=lifespan)


@app.get("/")
async def root() -> dict[str, str]:
    return {"service": "auto-otclick-bot", "status": "ok"}


@app.get("/health")
async def health() -> dict[str, object]:
    return {
        "status": "ok",
        "telegram_configured": bool(settings.telegram_bot_token),
        "telegram_mode": settings.telegram_mode,
        "openai_configured": bool(settings.openai_api_key),
        "imap_enabled": settings.imap_enabled,
        "two_gis_configured": bool(settings.two_gis_api_key),
    }


@app.post("/telegram/webhook")
async def telegram_webhook(request: Request) -> dict[str, bool]:
    bot: Bot | None = getattr(request.app.state, "bot", None)
    dispatcher: Dispatcher | None = getattr(request.app.state, "dispatcher", None)
    services: AppServices | None = getattr(request.app.state, "services", None)
    if not bot or not dispatcher or not services:
        raise HTTPException(status_code=503, detail="Telegram is not configured")
    if settings.telegram_webhook_secret:
        received = request.headers.get("X-Telegram-Bot-Api-Secret-Token", "")
        if received != settings.telegram_webhook_secret:
            raise HTTPException(status_code=403, detail="Invalid webhook secret")
    update = Update.model_validate(await request.json(), context={"bot": bot})
    await dispatcher.feed_update(bot, update, services=services)
    return {"ok": True}


if __name__ == "__main__":
    uvicorn.run("app.main:app", host="0.0.0.0", port=settings.port, reload=False)
