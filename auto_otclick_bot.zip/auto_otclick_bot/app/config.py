from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    telegram_bot_token: str = ""
    telegram_admin_ids: list[int] = Field(default_factory=list)
    telegram_mode: str = "polling"
    telegram_webhook_base_url: str = ""
    telegram_webhook_secret: str = ""

    openai_api_key: str = ""
    openai_model: str = "gpt-5.6-luna"

    database_url: str = "sqlite+aiosqlite:///./data/app.db"
    port: int = 10000
    log_level: str = "INFO"

    imap_enabled: bool = False
    imap_host: str = "imap.gmail.com"
    imap_port: int = 993
    imap_username: str = ""
    imap_password: str = ""
    imap_folder: str = "INBOX"
    email_poll_seconds: int = 60
    max_tasks_per_email_poll: int = 20

    two_gis_api_key: str = ""
    two_gis_page_size: int = 10
    two_gis_max_pages: int = 5
    two_gis_only_without_website: bool = True
    max_leads_per_search: int = 20

    prices_path: Path = Path("config/prices.yaml")

    @field_validator("telegram_admin_ids", mode="before")
    @classmethod
    def parse_admin_ids(cls, value: object) -> list[int]:
        if value in (None, ""):
            return []
        if isinstance(value, list):
            return [int(v) for v in value]
        return [int(part.strip()) for part in str(value).split(",") if part.strip()]

    @field_validator("database_url")
    @classmethod
    def normalize_database_url(cls, value: str) -> str:
        if value.startswith("postgres://"):
            return value.replace("postgres://", "postgresql+asyncpg://", 1)
        if value.startswith("postgresql://") and "+asyncpg" not in value:
            return value.replace("postgresql://", "postgresql+asyncpg://", 1)
        return value


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
