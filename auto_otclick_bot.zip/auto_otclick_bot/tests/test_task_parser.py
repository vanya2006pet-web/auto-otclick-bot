from app.services.task_parser import TaskParser


def test_manual_parser_extracts_budget_and_url():
    parser = TaskParser()
    task = parser.parse_manual(
        "Нужно сделать лендинг\nБюджет 20 000 руб.\nhttps://kwork.ru/projects/123"
    )
    assert task.source == "kwork"
    assert task.budget == 20_000
    assert task.url == "https://kwork.ru/projects/123"


def test_manual_parser_without_budget():
    parser = TaskParser()
    task = parser.parse_manual("Разработать Telegram-бота для обработки заявок клиентов")
    assert task.budget is None
    assert task.source == "manual"
