from pathlib import Path

from app.services.pricing import PricingService


PRICES = Path(__file__).parents[1] / "config" / "prices.yaml"


def test_classifies_landing():
    service = PricingService(PRICES)
    assert service.classify("Нужно разработать адаптивный лендинг") == "landing"


def test_classifies_telegram_bot_before_generic_app():
    service = PricingService(PRICES)
    assert service.classify("Создать Telegram-бота для заявок") == "telegram_bot"


def test_platform_price_is_capped_by_budget():
    service = PricingService(PRICES)
    result = service.calculate_platform("landing", "medium", 20_000)
    assert result["recommended_price"] <= 17_000
    assert result["recommended_price"] >= 10_000


def test_direct_price_uses_category():
    service = PricingService(PRICES)
    assert service.direct_lead_price("Стоматология") == 75_000
